<?php 
include'../config/db.php';
include'../config/main_function.php';
include'../config/functions.php';
if(empty($_SESSION['login_user'])){
  header("Location: ../index.php");
  exit;
}
//Computation of Total//
$selectReserve = single_get("*","tcode","reservations",$_GET['tcode']);//Select Reservation
$packages = single_get("*","code","packages",$selectReserve['package_code']);//Select Packages

$otherQuery = "SELECT * FROM reservation_others 
INNER JOIN amenities on amenities.a_name = reservation_others.amenity_name
WHERE reservation_others.tcode='".$_GET['tcode']."'";
$others = single_inner_join($otherQuery);//Select Other Amenities

$menuQuery = "SELECT SUM(cost_per_head) as total  FROM menu_selection
INNER JOIN food_items on food_items.item_id = menu_selection.item_id
WHERE menu_selection.tcode = '".$_GET['tcode']."'";
$menu = single_inner_join($menuQuery);//Menu Selection

$paxQuery = "SELECT SUM(pax_price * pax_person) as totalPax  FROM additional_pax WHERE tcode = '".$_GET['tcode']."'";
$pax = single_inner_join($paxQuery);//Additional Pax

$themeQuery = "SELECT * FROM reservations INNER JOIN themes on themes.theme_name = reservations.event_theme  WHERE tcode = '".$_GET['tcode']."'";
$theme = single_inner_join($themeQuery);

$getReservation = single_get("*","setting_id","site_settings",'4');//get reservation fee
$getTransportation = single_get("*","setting_id","site_settings",'5');//get transportation fee
$getDownpayment = single_get("*","setting_id","site_settings",'2');//get transportation fee

if($selectReserve['city_location'] == 'Inside Valenzuela City'){
  $getTotal = $getReservation['setting_value'] + ($others['quantity'] * $others['a_price']) + $packages['total_price'] + ($menu['total'] + $pax['totalPax']) + $theme['theme_price'];
}else{
  $getTotal = $getReservation['setting_value'] + $getTransportation['setting_value'] + ($others['quantity'] * $others['a_price']) + $packages['total_price'] + ($menu['total'] + $pax['totalPax']) + $theme['theme_price'];
}

$Downpayment = $getTotal * ($getDownpayment['setting_value'] / 100);
$Balance = $getTotal - $Downpayment;   
//end computation //
if(isset($_POST['save_button'])){
  $tcode = filter($_GET['tcode']);
  $update = $dbcon->query("UPDATE reservations SET reservation_status = 'Posted' WHERE tcode= '$tcode'") or die(mysqli_error());
  header("location: reservations.php");
}
if(isset($_GET['ms_id'])){
  $ms_id = filter($_GET['ms_id']);
  $tcode = filter($_GET['tcode']);
    $ar = array("ms_id"=>$ms_id);
    $tbl_name = "menu_selection";
    $del = delete($dbcon,$tbl_name,$ar);
    if($del){
      header("location: other-reservation.php?tcode=$tcode&tab=3");
    }
}
if(isset($_GET['ro_id'])){
  $ro_id = filter($_GET['ro_id']);
  $tcode = filter($_GET['tcode']);
    $ar = array("ro_id"=>$ro_id);
    $tbl_name = "reservation_others";
    $del = delete($dbcon,$tbl_name,$ar);
    if($del){
      header("location: other-reservation.php?tcode=$tcode&tab=4");
    }
}
if(isset($_GET['pax_id'])){
  $pax_id = filter($_GET['pax_id']);
  $tcode = filter($_GET['tcode']);
  $tab= $_GET['tab'];
    $ar = array("pax_id"=>$pax_id);
    $tbl_name = "additional_pax";
    $del = delete($dbcon,$tbl_name,$ar);
    //if($del){
      //header("location: other-reservation.php?tcode=$tcode&tab=$tab");
    //}
}
if(isset($_GET['ex_id'])){
  $ex_id = filter($_GET['ex_id']);
  $tcode = filter($_GET['tcode']);
  $tab= $_GET['tab'];
    $ar = array("ex_id"=>$ex_id);
    $tbl_name = "package_extension";
    $del = delete($dbcon,$tbl_name,$ar);
    //if($del){
      //header("location: other-reservation.php?tcode=$tcode&tab=$tab");
    //}
}
?>

<?php include'../assets/user_header.php';?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Main content -->
    <section class="content">


      <div class="row">
       <div class="container">
        
        <div class="box box-info" style="width:97%;">
            <div class="box-body">
            <!-- Custom Tabs -->
          <div class="nav-tabs-custom">
            <ul class="nav nav-tabs">
              <li <?php if($_GET['tab'] == '1'): echo "class='active'"; endif;?>><a href="#tab_1" data-toggle="tab"><i class="fa fa-calendar"></i> RESERVATION DETAILS</a></li>
              <li <?php if($_GET['tab'] == '2'): echo "class='active'"; endif;?>><a href="#tab_2" data-toggle="tab"><i class="fa fa-cubes"></i> PACKAGE DETAILS</a></li>
              <li <?php if($_GET['tab'] == '3'): echo "class='active'"; endif;?>><a href="#tab_3" data-toggle="tab"><i class="fa fa-file-text"></i> MENU SELECTION</a></li>
              <li <?php if($_GET['tab'] == '4'): echo "class='active'"; endif;?>><a href="#tab_4" data-toggle="tab"><i class="fa fa-gear"></i> OTHER SERVICES</a></li>
              <li <?php if($_GET['tab'] == '5'): echo "class='active'"; endif;?>><a href="#tab_5" data-toggle="tab"><i class="fa fa-users"></i> ADDITIONAL PAX</a></li>
            </ul>
            <div class="tab-content">
              <div class="tab-pane <?php if($_GET['tab'] == '1'):?>active<?php endif;?>" id="tab_1">
            <div class="row">
            <?php $pName = single_get("*","tcode","reservations",$_GET['tcode']);?>
              <div class="col-md-6">
                <strong>Event Name:</strong>
                <br>
                <input type="text" name="event_name" readonly="readonly" class="form-control" value="<?php echo $pName['event_name']?>">
              </div>
              <div class="col-md-6">
                <strong>City:</strong>
                <br>
                <input type="text" name="event_name" readonly="readonly" class="form-control" value="<?php echo $pName['event_city']?>">
              </div>
            </div>
            <br>
            <div class="row">
              <div class="col-md-6">
                <strong>Date:</strong>
                <br>
                <input type="date" name="event_name" readonly="readonly" class="form-control" value="<?php echo $pName['event_date']?>">
              </div>
              <div class="col-md-6">
                <strong>Theme:</strong><br>
                <input type="text" name="event_name" readonly="readonly" class="form-control" value="<?php echo $pName['event_theme']?>">
              </div>
            </div>
            <br>
            <div class="row">
              <div class="col-md-6">
                <strong>Time:</strong>
                <br>
                <input type="time" name="event_name" readonly="readonly" class="form-control" value="<?php echo $pName['event_time']?>">
              </div>
              <div class="col-md-6">
                <strong>Color Motiff:</strong>
                <br>
                <input type="text" name="event_name" readonly="readonly" class="form-control" value="<?php echo $pName['event_color']?>">
                
              </div>
            </div>
            <br>
            <div class="row">
              <div class="col-md-6">
                <strong>Venue:</strong>
                <br>
                <textarea class="form-control" name="event_venue" readonly="readonly"><?php echo $pName['event_venue']?></textarea>
              </div>
              <div class="col-md-6">
                <strong>Special Instructions:</strong>
                <br>
                <textarea class="form-control" name="event_instructions" readonly="readonly"><?php echo $pName['event_instructions']?></textarea>
                <br>
              </div>
              <div class="col-md-6">
                <strong>Downpayment <div class="label label-primary">(Upon Reservation)</div></strong>
                <br><br>
                <input type="text" name="event_name" readonly="readonly" class="form-control" value="<?php echo number_format($Downpayment)?>">
              </div><br>
              <div class="col-md-6">
                <strong>Balance <div class="label label-danger">(To be paid before)</div></strong>
                <br><br>
                <input type="text" name="event_name" readonly="readonly" class="form-control" value="<?php echo number_format($Balance)?>"><br>
              </div>
              <div class="col-md-6">
                <strong>City Location:</strong>
                <br>
                <input type="text" name="event_name" readonly="readonly" class="form-control" value="<?php echo $pName['city_location']?>">
              </div>
              <div class="col-md-6">
                <strong>Total Amount:</strong>
                <br>
                <input type="text" name="event_name" readonly="readonly" class="form-control" value="<?php echo number_format($getTotal);?>">
              </div>
            </div>
            
              <br>
              <!--
              <button class="btn btn-primary" name="save_button"><i class="fa fa-save"></i> Save</button>
            -->
              <a href="add-pax.php?tcode=<?php echo $_GET['tcode']?>" class="btn btn-danger"><i class="fa fa-plus"></i> Additional Pax</a> 
             
              <?php if($selectReserve['reservation_status'] == 'Draft'):?>
               <a href="checkout.php?tcode=<?php echo filter($_GET['tcode']);?>" class="btn btn-success"><i class="fa fa-file"></i> View Details</a>
              <?php elseif($selectReserve['reservation_status'] == 'Paid Initial Deposit'):?>
                
                <a href="checkout.php?tcode=<?php echo filter($_GET['tcode']);?>" class="btn btn-success"><i class="fa fa-shopping-cart"></i> Pay Remainig Balance</a>
              <?php else:?>

              <?php endif;?>
            
              <a href="reservation-package.php" class="btn btn-default"><i class="fa fa-arrow-left"></i> Back</a>
                           
              </div>
              <!-- /.tab-pane -->
              <div class="tab-pane <?php if($_GET['tab'] == '2'):?>active<?php endif;?>" id="tab_2">
              <?php $pDetails = single_get("*","tcode","reservations",$_GET['tcode']);?>
              <?php 
              $kweri = "SELECT * FROM packages INNER JOIN menu on menu.menu_id = packages.menu_type WHERE code = '".$pDetails['package_code']."'";
              $details = single_inner_join($kweri);
              ?>  
                <div class="row">
                  <div class="col-md-7">
                    <strong>Name:</strong>
                    <br>
                    <input type="text" class="form-control" value="<?php echo $details['package_name']?>" readonly="readonly">
                    <br>
                    <strong>Description:</strong>
                    <br>
                    <input type="text" class="form-control" value="<?php echo $details['package_desc']?>" readonly="readonly">
                    <br>
                    <strong>No. of Person:</strong>
                    <br>
                    <input type="text" class="form-control" value="<?php echo $details['no_person']?>" readonly="readonly">
                    <br>
                     <strong>Menu:</strong>
                    <br>
                    <input type="text" class="form-control" value="<?php echo $details['menu_name']?>" readonly="readonly">
                    <br>
                     <strong>Per head Amount:</strong>
                    <br>
                    <input type="text" class="form-control" value="<?php echo $details['per_head']?>" readonly="readonly">
                    <br>
                     <strong>Total Price:</strong>
                    <br>
                    <input type="text" class="form-control" value="<?php echo $details['total_price']?>" readonly="readonly">
                    
                  </div>
                  <div class="col-md-5">
                    <h4><?php echo $details['package_name']?></h4>
                    <hr>
                    <?php 
                      $query = "SELECT * FROM package_extension WHERE code = ".$pDetails['package_code']." ORDER BY `package_extension`.`package_sync` DESC";
                      $fetchEx = getdata_inner_join($query);
                      ?>
                      <?php if(!empty($fetchEx)):?>
                  <ul>
                <?php foreach ($fetchEx as $key => $value):?>
                  <li><?php echo $value->ex_name?></li>
                <?php endforeach;?>
                  </ul>
              <?php else:?>
                <div class="alert alert-danger">No records on the database.</div>
              <?php endif;?>

                  </div>

                </div>
                <hr>
                  <h4>Food Menu Details</h4>
                <div class="alert alert-info"><strong>Note: </strong><br>
                These are the list of detailed menu with your choice.</div>
                <?php 
                $menuQuery = "SELECT * FROM menu_list_information INNER JOIN food_items on food_items.item_id = menu_list_information.item_id WHERE menu_code='".$_GET['tcode']."'";
                $kweri = getdata_inner_join($menuQuery);
                ?>
                <?php if(!empty($kweri)):?>
                  <table class="table table-bordered">
                    <tr>
                      <td>Name</td>
                      <td>Cost per head</td>
                    </tr>
                 
                <?php foreach ($kweri as $key => $value):?>
                   <tr>
                      <td><?php echo $value->item_name?></td>
                      <td><?php echo $value->cost_per_head?></td>
                    </tr>
                <?php endforeach;?>
                 </table>
                <?php else:?>
                  <div class="alert alert-danger">No records on the database.</div>
                <?php endif;?>
                <hr>
                <h4>Additional Menu</h4>
                <div class="alert alert-info"><strong>Note: </strong><br>
                These are the list of additional menu that the customer added.</div>
                <?php 
                $menuQuery = "SELECT * FROM menu_selection INNER JOIN food_items on food_items.item_id = menu_selection.item_id WHERE tcode='".$_GET['tcode']."'";
                $kweri = getdata_inner_join($menuQuery);
                ?>
                <?php if(!empty($kweri)):?>
                  <table class="table table-bordered">
                    <tr>
                      <td>Name</td>
                      <td>Cost per head</td>
                    </tr>
                 
                <?php foreach ($kweri as $key => $value):?>
                   <tr>
                      <td><?php echo $value->item_name?></td>
                      <td><?php echo $value->cost_per_head?></td>
                    </tr>
                <?php endforeach;?>
                 </table>
                <?php else:?>
                  <div class="alert alert-danger">No records on the database.</div>
                <?php endif;?>
              </div>
              
              <!-- /.tab-pane -->
              <div class="tab-pane <?php if($_GET['tab'] == '3'):?>active<?php endif;?>" id="tab_3">
              <?php if(isset($msg)): echo $msg; endif;?>
              <hr>
               <?php
  if(isset($_POST['save_list']) != '')
  {
    $code = single_get("*","tcode","reservations",$_GET['tcode']);
    $package = single_get("*","code","packages",$code['package_code']);
    $extensionQuery = "SELECT * FROM package_extension WHERE code = '".$package['code']."' AND ex_name LIKE '%Choices of%'";
    $extension = single_inner_join($extensionQuery);
    $menuQuery = "SELECT COUNT(*) as total FROM menu_list_information WHERE menu_code='".$_GET['tcode']."'";
    $count = single_inner_join($menuQuery);
                
    if($extension['package_menu'] == $count['total']){
                  
                  
    echo '<div class="alert alert-danger">You already select the maximum number of choices which is '.$count['total'].'</div>';
                  
    }else{
      if(empty($_POST['checkboxstatus'])) {            
        echo '<div class="alert alert-danger">Please select choices</div>';                 
      }
      else{
        $checked_values = $_REQUEST['checkboxstatus'];
        foreach($checked_values as $val) {
                        
          $insertSQL = array("item_id"=>$val,"menu_code"=>$_GET['tcode']);
          $success = insertdata("menu_list_information",$insertSQL);  
        header("location:other-reservation.php?tcode=".$_GET['tcode']."&tab=3");
                        }
        }
      }
  }
  ?>
              <form method="post">
               <?php 
                $code = single_get("*","tcode","reservations",$_GET['tcode']);
                $package = single_get("*","code","packages",$code['package_code']);
                $choice =single_get("*","menu_id","menu",$package['menu_type']);
                $extensionQuery = "SELECT * FROM package_extension WHERE code = '".$package['code']."' AND ex_name LIKE '%Choices of%'";
                $result = single_inner_join($extensionQuery);
               ?>
               <h4>Menu: <?php echo $result['ex_name'];?></h4>
            
             <?php if(substr($choice['menu_name'],5,2) === 'w/'):?>
               <?php 
               $foodQuery = 'SELECT * FROM food_items INNER JOIN food_categories on food_categories.f_id = food_items.item_category';
               $list = getdata_inner_join($foodQuery);
               ?>
              <?php if(!empty($list)):?>
                <table class="table table-bordered">
                  <tr>
                    <td></td>
                    <td>Photo</td>
                    <td>Name</td>
                    <td>Category</td>
                    <td>Cost Per Head</td>
                  </tr>
              <?php foreach ($list as $key2 => $result):?>
               <tr>
                    <td><input type="checkbox" name="checkboxstatus[<?php echo $key2;?>]" value="<?php echo $result->item_id; ?>"></td>
                    <td> <img src="../images/<?php echo $result->itm_image?>" class="img-thumbnail" width="150"></td>
                    <td><?php echo $result->item_name?></td>
                    <td><?php echo $result->f_name?></td>
                    <td><?php echo number_format($result->cost_per_head)?></td>
                  </tr>
               
              <?php endforeach;?>
               </table>
               
              <?php else:?>
                <option>No records</option>
              <?php endif;?>
              <hr>
            
            <?php elseif(ucfirst(substr($choice['menu_name'],5,7)) === 'Without'):?>
             
               <?php 
               $row1 = ucfirst(substr($choice['menu_name'],13));

               $query = "SELECT * FROM food_items INNER JOIN food_categories on food_categories.f_id=
               food_items.item_category WHERE food_categories.f_name != '$row1'";
               $without = getdata_inner_join($query);
               ?>
              <?php if(!empty($without)):?>
                 <table class="table table-bordered">
                  <tr>
                    <td></td>
                    <td>Photo</td>
                    <td>Name</td>
                    <td>Category</td>
                    <td>Cost Per Head</td>
                  </tr>
              <?php foreach ($without as $key => $fetchFood):?>
                <tr>
                    <td><input type="checkbox" name="checkboxstatus[<?php echo $key;?>]" value="<?php echo $fetchFood->item_id; ?>"></td>
                    <td> <img src="../images/<?php echo $fetchFood->itm_image?>" class="img-thumbnail" width="150"></td>
                    <td><?php echo $fetchFood->item_name?></td>
                    <td><?php echo $fetchFood->f_name?></td>
                    <td><?php echo number_format($fetchFood->cost_per_head)?></td>
                  </tr>
              <?php endforeach;?>
                   </table>
              <?php else:?>
                <option>No records</option>
              <?php endif;?>
            <?php endif; ?>
            </select>
            <button class="btn btn-success" name="save_list"><i class="fa fa-save"></i> Save List</button>
            </form>
            <hr>
              <h4>Additional Menu:</h4>
              <a href="add-menu.php?tcode=<?php echo $_GET['tcode']?>" class="btn btn-info"><i class="fa fa-plus"></i> Add Menu</a>
              <br><br>
              <form method="post">
              <?php 
              $query = "SELECT * FROM menu_selection INNER JOIN food_items on food_items.item_id = menu_selection.item_id WHERE menu_selection.tcode='".$_GET['tcode']."'";
              $list = getdata_inner_join($query);
              ?>
              <?php if(!empty($list)):?>
              <div class="row">
              <?php foreach ($list as $key => $value):?>
                <div class="col-md-2">
                  <img src="../images/<?php echo $value->itm_image?>" class="img-thumbnail" width="250">
                  <br>
                  <center><strong><?php echo $value->item_name?></strong><br>
                  Cost per head: &#8369; <?php echo $value->cost_per_head;?><br>
                  <a href="other-reservation.php?ms_id=<?php echo $value->ms_id?>&tcode=<?php echo $_GET['tcode']?>"><i class="fa fa-remove"></i> Delete</a></center>
                </div>

              <?php endforeach;?>
              </div>
            <?php else:?>
              <div class="alert alert-danger">There are no records on the database.</div>
            <?php endif;?>

              </form>
              </div>
              <div class="tab-pane <?php if($_GET['tab'] == '4'):?>active<?php endif;?>" id="tab_4">
              <a href="add-other.php?tcode=<?php echo $_GET['tcode']?>" class="btn btn-info"><i class="fa fa-plus"></i> Add Item</a><br>
              <br>
              <h4>Other Amenities</h4>
               <?php $others = getdata_where("*","tcode","reservation_others",$_GET['tcode']);?>
               <?php if(!empty($others)):?>
                <table class="table table-bordered">
                  <tr>
                    <td>Amenity Name</td>
                    <td>Quantity</td>
                    <td>Subtotal</td>
                    <td>Options</td>
                  </tr>
              <?php foreach ($others as $key => $value):?>
                <tr>
                    <td><?php echo $value->amenity_name?></td>
                    <td><?php echo $value->quantity?></td>
                    <td>
                      &#8369; <?php $query = $dbcon->query("SELECT * FROM amenities WHERE a_name = '".$value->amenity_name."'") or die(mysqli_error());
                      $result = $query->fetch_assoc();
                      $total = $result['a_price'] * $value->quantity;
                      echo number_format($total);
                      ?>
                    </td>
                    <td><a href="other-reservation.php?tcode=<?php echo $_GET['tcode']?>&ro_id=<?php echo $value->ro_id?>"><i class="fa fa-remove"></i> Delete</a></td>
                  </tr>
              <?php endforeach;?>
              </table>
            <?php else:?>
              <div class="alert alert-danger">There are no records on the database.</div>
            <?php endif;?>
            <hr>
            <h4>Freebies</h4>
            <a href="add-product.php?tcode=<?php echo $_GET['tcode']?>" class="btn btn-info"><i class="fa fa-plus"></i> Add Product</a><br><br>
             <?php $others = getdata_where("*","code","package_extension",$_GET['tcode']);?>
               <?php if(!empty($others)):?>
                <table class="table table-bordered">
                  <tr>
                    <td>Product Name</td>
                    <td>Quantity</td>
                    <td>Price</td>
                    <td>Total</td>
                    <td>Options</td>
                  </tr>
              <?php foreach ($others as $key => $value):?>
                <tr>
                    <td><?php echo $value->ex_name?></td>
                    <td><?php echo $value->ex_price?></td>
                    <td><?php echo $value->ex_qty?></td>
                    <td>
                      &#8369; <?php $total = $value->ex_price * $value->ex_qty; echo $total;?>
                      
                    </td>
                    <td><a href="other-reservation.php?tcode=<?php echo $_GET['tcode']?>&ex_id=<?php echo $value->ex_id?>"><i class="fa fa-remove"></i> Delete</a></td>
                  </tr>
              <?php endforeach;?>
              </table>
            <?php else:?>
              <div class="alert alert-danger">There are no records on the database.</div>
            <?php endif;?>
               
              </div>
              <div class="tab-pane <?php if($_GET['tab'] == '5'):?>active<?php endif;?>" id="tab_5">
              <a href="add-pax.php?tcode=<?php echo $_GET['tcode']?>" class="btn btn-info"><i class="fa fa-plus"></i> Add Additional Pax</a><br>
              <br>
               <?php $others = getdata_where("*","tcode","additional_pax",$_GET['tcode']);?>
               <?php if(!empty($others)):?>
                <table class="table table-bordered">
                  <tr>
                    <td>Name</td>
                    <td>No. of Persons</td>
                    <td>Total</td>
                    <td>Option</td>
                  </tr>
              <?php foreach ($others as $key => $value):?>
                <tr>
                    <td><?php echo $value->pax_name?></td>
                    <td><?php echo $value->pax_person?></td>
                    <td>&#8369; <?php $total = $value->pax_person * $value->pax_price; echo number_format($total);?></td>
                    <td><a href="other-reservation.php?tcode=<?php echo $_GET['tcode']?>&pax_id=<?php echo $value->pax_id?>&tab=5"><i class="fa fa-remove"></i> Delete</a></td>
                  </tr>
              <?php endforeach;?>
              </table>
            <?php else:?>
              <div class="alert alert-danger">There are no records on the database.</div>
            <?php endif;?>
               
              </div>
              <!-- /.tab-pane -->
            </div>
            <!-- /.tab-content -->
          </div>
            </div>
            
          </div>
          <hr>
          
       </div>
      </div>
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
<?php include'../assets/user_footer.php';?>