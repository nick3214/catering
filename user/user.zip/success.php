<?php 
include'../config/db.php';
include'../config/main_function.php';
include'../config/functions.php';
if(empty($_SESSION['login_user'])){
  header("Location: ../index.php");
  exit;
}

$item_no = $_GET['item_number'];
$item_transaction = $_GET['tx'];
$item_price = $_GET['amt'];
$item_currency = $_GET['cc'];

$kweri = $dbcon->query("SELECT COUNT(*) as totalTXFROM transactions WHERE tcode = '$item_no'") or die(mysqli_error());
$checkPaypal = $kweri->fetch_assoc();

if($checkPaypal['total'] == '0'){
  $result = mysqli_query($dbcon,"INSERT INTO transactions (`tcode`,`tx`,`amt`,`t_status`,`user_id`) VALUES ('$item_no','".$_GET['tx']."','$item_price','0','".$_SESSION['user_id']."')");
  if($result){
    $updateQuery = $dbcon->query("UPDATE reservations SET reservation_status = 'Paid Initial Deposit' WHERE tcode = '$item_no'") or die(mysqli_error());
    $msg = 'You haves successfully paid the initial deposit worth: &#8369; '.$_GET['amt'].'';
  }else{
      $msg = "Payment Error";
  }
}elseif($checkPaypal['total'] == '1'){
   $result = mysqli_query($dbcon,"INSERT INTO transactions (`tcode`,`tx`,`amt`,`t_status`,`user_id`) VALUES ('$item_no','".$_GET['tx']."','$item_price','1','".$_SESSION['user_id']."')");
  if($result){
    $updateQuery = $dbcon->query("UPDATE reservations SET reservation_status = 'Fully Paid' WHERE tcode = '$item_no'") or die(mysqli_error());
    $msg = 'You haves successfully paid the initial deposit worth: &#8369; '.$_GET['amt'].'';
  }else{
      $msg = "Payment Error";
  }
}else{
  $msg = 'Opps you are trying to hack the site.';
}






?>
<?php include'../assets/user_header.php';?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Main content -->
    <section class="content">


      <div class="row">
       <div class="container">
        
        <div class="box box-info" style="width:97%;">
            <div class="box-body">
            <!-- Start -->
    <!-- Main content -->
    <section class="invoice">
      <!-- title row -->
      <div class="row">
        <div class="col-xs-12">
          <h2 class="page-header">
            <i class="fa fa-shopping-cart"></i> Billing Status
            <small class="pull-right">Date: <?php echo date("m/d/Y");?></small>
          </h2>
        </div>
        <!-- /.col -->
      </div>
      <div class="row">
        <!-- accepted payments column -->
      <div class="alert alert-success">
        <h2><?php if(isset($msg)): echo $msg; endif;?></h2>
      </div>
      <a href="reservations.php" class="btn btn-danger"><i class="fa fa-arrow-left"></i> Click here to return</a>
    </section>
            <!-- End-->
            </div>
            
          </div>
          <hr>
          
       </div>
      </div>
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
<?php include'../assets/user_footer.php';?>