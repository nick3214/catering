<?php 
include'../config/db.php';
include'../config/main_function.php';
include'../config/functions.php';
if(empty($_SESSION['login_user'])){
  header("Location: ../index.php");
  exit;
}
if(isset($_POST['save_button'])){
  $pax_price = filter($_POST['pax_price']);
  $pax_person = filter($_POST['pax_person']);
  $tcode = filter($_GET['tcode']);
  $insertSQL = array("pax_name"=>"Additional ".$pax_person." PAX (Package: ".$pax_price." + Additinoal:00 per Head","pax_person"=>$pax_person,"pax_price"=>$pax_price,"tcode"=>$tcode);
  insertdata("additional_pax",$insertSQL);
  header("location: other-reservation.php?tcode=$tcode&tab=5");
}
?>
<?php include'../assets/user_header.php';?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Main content -->
    <section class="content">


      <div class="row">
       <div class="container">
        
        <div class="box box-info" style="width:97%;">
            <div class="box-header">
              

              <h4 class="box-title">ADD ADDITIONAL PAX</h4>
            </div>
            <hr>
            <div class="box-body">
            <form method="post">
            <?php 
            $code = single_get("*","tcode","reservations",$_GET['tcode']);
            $amount = single_get("*","code","packages",$code['package_code']);
            ?>
            <h4>Package: <?php echo $code['package_name']?></h4>
              <strong>Amount per Head (Package + Additional Food):</strong>
                <br>
                <input type="text" name="pax_price" class="form-control"
                value="<?php echo $amount['per_head'];?>" readonly="readonly">
            <br>
            <strong>No. of persons:</strong>
                <br>
                <input type="text" name="pax_person" class="form-control" placeholder="No. of Persons">
            <br>
             
            <div class="row">
            <center>
              <br>
              <button class="btn btn-primary" name="save_button"><i class="fa fa-save"></i> Save Data</button>
            </center>
            </form>
            </div>
            
          </div>
          <hr>
          
       </div>
      </div>
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
<?php include'../assets/user_footer.php';?>