<?php 
include'../config/db.php';
include'../config/main_function.php';
include'../config/functions.php';
if(empty($_SESSION['login_user'])){
  header("Location: ../index.php");
  exit;
}
?>
<?php include'../assets/user_header.php';?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Main content -->
    <section class="content">
      <!-- Small boxes (Stat box) -->


      <div class="row">
       <div class="container">
          <div class="box box-info" style="width:97%;">
            <div class="box-header">
              <h4 class="box-title"><i class="fa fa-list"></i> List of Packages</h4>
            </div>
            <div class="box-body">
              <div class="row" style="margin:1px;">
              <?php $package = getdata("*","packages");?>
              <?php if(!empty($package)):?>
              <?php foreach ($package as $key =>$value):?>
                <div class="col-md-4 package" >
                  <div class="box box-danger" style="width:97%;">
                    <div class="box-header">
                      <center><img src="../images/<?php echo $value->package_photo?>" class="img-thumbnail" width="150"></center>
                      <h4 class="box-title"><?php echo $value->package_name?> - &#8369; <?php echo $value->total_price?></h4>
                      <?php if($value->no_person == '0'):?>
                  Min. of <?php echo $value->no_adults?> pax-adults & <?php echo $value->no_kids;?>pax-kids
                <?php else:?>
                <h4>Minimum of <?php echo $value->no_person;?> pax</h4>
              <?php endif;?>
                      <?php 
                      $query = "SELECT * FROM package_extension WHERE code = ".$value->code." ORDER BY `package_extension`.`package_sync` DESC";
                      $fetchEx = getdata_inner_join($query);
                      ?>
                      <?php if(!empty($fetchEx)):?>
                  <ul>
                <?php foreach ($fetchEx as $key => $value):?>
                  <li><?php echo $value->ex_name?></li>
                <?php endforeach;?>
                  </ul>
              <?php else:?>
                <div class="alert alert-danger">No records on the database.</div>
              <?php endif;?>
                    </div>
                  </div>
                </div>
              <?php endforeach;?>
            <?php else:?>
              <div class="alert alert-danger">There are no records on the database.</div>
            <?php endif;?>
               
              </div>
            </div>
            
          </div>
       </div>
      </div>
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
<style type="text/css">
  .package{
    padding:5px;
  }
</style>
<?php include'../assets/user_footer.php';?>